# facebook-ai-studio — رواة الواقع Branding & Automation Pack

نظام أتمتة الهوية البصرية والصوتية لقناة **رواة الواقع** (قصص واقعية)، مبني فوق
pipeline الفيديو الحالي (MoneyPrinterTurbo + Gemini + Pexels)، ومصمم للعمل
مجانًا بالكامل على GitHub Actions.

## المكوّنات

| الموديول | الوظيفة |
|---|---|
| `core/intro_builder.py` | إنترو افتتاحي (شعار كامل الشاشة + جينجل، 2-4 ثواني) |
| `core/watermark.py` | علامة مائية صغيرة (~20% من عرض الفريم) تظهر وتختفي دوريًا في زاوية مختلفة كل مرة |
| `core/video_assembler.py` | يجمع الإنترو + الحلقة الخام + العلامة المائية في فيديو نهائي واحد |
| `core/voice_clone.py` | استنساخ صوتك الشخصي عبر XTTS v2 للتعليق الصوتي |
| `core/teaser_builder.py` | تيزر تشويقي (10-15 ثانية) بصوت whisper، بدون حل اللغز |
| `core/shorts_builder.py` | الشورت اللي بينزل بعد الحلقة بسؤال ناقص + `growth_metrics.json` |
| `scripts/best_time.py` | يحسب أفضل وقت نشر من بيانات YouTube Studio |

## الإعدادات

كل حاجة قابلة للتعديل من `config/channel_profile.json`: حجم العلامة المائية،
مدة ظهورها/اختفائها، الأركان المسموحة، توقيت التيزر قبل الحلقة، إلخ.

## التشغيل محليًا

```bash
pip install -r requirements.txt

# 1) توليد التعليق الصوتي بصوتك
python -m core.voice_clone \
  --script-file content/scripts/long/case-001-EP01.txt \
  --reference-audio .private/voice/reference.wav \
  --output storage/autopilot/case-001-EP01.mp3

# 2) تجميع الحلقة كاملة (إنترو + الحلقة الخام من MoneyPrinterTurbo + علامة مائية)
python -m core.video_assembler \
  --raw-episode path/to/raw_episode.mp4 \
  --output storage/autopilot/case-001-EP01-final.mp4

# 3) بناء التيزر
python -m core.teaser_builder \
  --logo assets/branding/rawaat_original_transparent.png \
  --hook-audio assets/audio/whisper_hook_sample.mp3 \
  --background-clip path/to/atmospheric_clip.mp4 \
  --output storage/autopilot/case-001-EP01-teaser.mp4

# 4) حساب أفضل وقت نشر (من CSV مُصدَّر من YouTube Studio)
python scripts/best_time.py --studio-csv path/to/audience_export.csv
```

## GitHub Actions (تشغيل مجاني بدون جهاز محلي)

- **`Personal Voice XTTS`** — يولّد التعليق الصوتي من الـ secret `VOICE_REFERENCE_B64`
- **`Build Episode`** — يجمّع الحلقة النهائية (إنترو + علامة مائية)
- **`Teaser Builder`** — يبني التيزر ويحسب وقت النشر الأمثل

كلهم `workflow_dispatch` (تشغيل يدوي بمدخلات) — تقدر تربطهم ببعض في workflow
واحد لاحقًا لو حبيت pipeline كامل باضغطة زر واحدة.

## ملاحظة مهمة عن جدولة النشر الفعلي

نشر الفيديو نفسه في الوقت المحسوب (قبل الحلقة بساعة) بيتطلب رفعه عبر
**YouTube Data API** مع تعيين حقل `status.publishAt` — ده بيخلي يوتيوب ينشره
تلقائيًا في الميعاد المحدد من غير ما تحتاج سيرفر شغال 24 ساعة. الخطوة دي لسه
محتاجة نضيفها كموديول `core/youtube_uploader.py` — جاهزين نبنيها في الخطوة
الجاية.

## المرجع الاستراتيجي

`docs/seo-strategy-rowat-alwaqe.pdf` — استراتيجية العناوين، الصور المصغّرة،
الكلمات المفتاحية، وخطة النشر/الاختبار الكاملة للقناة.

## أمان

الصوت المرجعي (`voice_reference_a.wav`) **لا يُرفع أبدًا** للمستودع — يتحول
لـ Base64 ويُخزَّن كـ GitHub secret فقط. راجع `docs/personal-voice-xtts.md`.
